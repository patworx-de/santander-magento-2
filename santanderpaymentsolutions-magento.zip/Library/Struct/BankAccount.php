<?php
namespace SantanderPaymentSolutions\SantanderPayments\Library\Struct;

class BankAccount extends Base {
	public $holder;
	public $iban;
	public $bic;
	public $usage;
}