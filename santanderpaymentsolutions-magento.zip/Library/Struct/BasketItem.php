<?php
namespace SantanderPaymentSolutions\SantanderPayments\Library\Struct;

class BasketItem extends Base {
	public $name;
	public $price;
	public $vat;
	public $quantity;
	public $id;
}